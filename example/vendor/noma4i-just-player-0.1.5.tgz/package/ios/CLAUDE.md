# ios/ - iOS Native Layer

> **Правила:** max 500 строк, БЕЗ истории, для AI

## Overview
- **Цель**: AVPlayer-based видеоплеер для iOS
- **Принцип**: Nitro Hybrids (Swift <-> C++ bridge), singleton VideoManager

## Файлы

### core/

| Файл | Назначение |
|------|------------|
| `VideoManager.swift` | Singleton: player registry, audio session, app lifecycle |
| `VideoPlayerObserver.swift` | KVO: source/player transitions + periodic ticks для unified playback snapshot |
| `VideoError.swift` | Error types |
| `VideoFileHelper.swift` | Resolve file:// и bundle:// URLs |

### core/Extensions/ (9 файлов)

AVAsset memory, AVAssetTrack orientation, AVMetadataItem factory, AVPlayerItem buffering/config, PiP, VideoInformation, safe selector, ResizeMode gravity

### hybrids/

| Файл | Назначение |
|------|------------|
| `VideoPlayer/HybridVideoPlayer.swift` | Player: play/pause/seek/volume/loop + native-first `PlaybackState` / `MemorySnapshot` |
| `VideoPlayer/HybridVideoPlayer+Events.swift` | AVPlayer -> unified playback snapshot transitions |
| `VideoPlayerSource/HybridVideoPlayerSource.swift` | Source: URL -> AVURLAsset, retention state cold / metadata / hot |
| `VideoPlayerSource/SourceLoader.swift` | Async loader с cancellation |
| `VideoPlayerEmitter/HybridVideoPlayerEventEmitter.swift` | JS event bridge |
| `VideoViewViewManager/HybridVideoViewViewManager.swift` | View props/events, fullscreen/PiP contract |

### view/

| Файл | Назначение |
|------|------------|
| `VideoComponentView.swift` | Main UIView: player attachment, PiP, resize |
| `VideoComponentViewObserver.swift` | View-level KVO observers |
| `fabric/` + `paper/` | Fabric/Paper bridges |

### hls/ - HLS Cache Proxy

| Файл | Назначение |
|------|------------|
| `HlsCacheProxyModule.swift` | RCT bridge module |
| `HlsCacheProxyModule.m` | ObjC bridge header |
| `HlsProxyServerController.swift` | GCDWebServer lifecycle + routes + AppState self-heal + HlsNetworkClient |
| `HlsManifestRewriter.swift` | M3U8 parsing + URL rewriting (cached static regex) |
| `HlsCacheStore.swift` | File cache: 5GB max, 7d TTL, LRU eviction, safe iteration |

## QC фиксы (текущее состояние)

- `HybridVideoPlayer`: artworkTask сохраняется как property, cancel в release()
- `HybridVideoPlayer`: init Task с [weak self] guard
- `HybridVideoPlayer`: isReleased guard предотвращает double-release
- `HybridVideoPlayer`: playback UI state идёт через единый `PlaybackState`, `isReadyToDisplay` обновляется из view observer
- `HybridVideoPlayer`: `readyToDisplay` должен быть доступен extension-ам player-а (не `private/fileprivate`), потому что lifecycle resets живут в `HybridVideoPlayer+Events.swift`
- `HybridVideoPlayer`: offscreen paused player trim-ится до `metadata`/`cold` по `memoryConfig`
- `HybridVideoPlayerSource`: metadata warmup хранит `AVURLAsset` отдельно от `AVPlayerItem`
- `HybridVideoPlayerSourceFactory`: ручной `NativeVideoConfig(...)` обязан оставаться в паритете с Nitro-generated signature, включая `useHlsProxy`
- `AVURLAsset+getAssetInformation`: `VideoInformation` собирается через final init, без мутаций immutable Nitro struct fields
- `HlsCacheStore`: eviction итерирует Array copy (не мутирует dictionary в цикле)
- `HlsCacheStore`: SHA256 filenames идут через `CommonCrypto`, импорт обязателен для `CC_SHA256*`
- `HlsCacheStore` + `HlsProxyServerController`: per-stream cache stats считаются по root manifest `streamKey`, который должен пробрасываться через nested manifests, init segments и media segments
- `HlsProxyServerController`: оба handlers (manifest+segment) возвращают 503 если self nil
- `HlsManifestRewriter`: static regex pattern
- `VideoPlayerObserver`: legibleOutput delegate (не metadataOutput)
- `VideoPlayerObserver`: outputs хранятся как properties и снимаются с observed item при смене source

## Правила

1. VideoManager.shared - единственный singleton, управляет audio session
2. isAudioSessionManagementDisabled = true (патч) - аудио сессией управляет приложение
3. wasAutoPaused - флаг сбрасывается при foreground, play управляется JS слоем
4. nitrogen/generated/ios/ - НЕ редактировать (autogen)
5. HLS proxy self-heals on didBecomeActive (auto-restart GCDWebServer)
6. iOS tests идут через podspec `UnitTests` test spec в `ios/Tests/`
7. Для playback JS не должен зависеть от раздельных progress/status/buffer callbacks; source of truth = `PlaybackState`
8. Memory lifecycle source of truth = `VideoConfig.memoryConfig`; `VideoComponentView` может инициировать delayed trim при уходе offscreen
