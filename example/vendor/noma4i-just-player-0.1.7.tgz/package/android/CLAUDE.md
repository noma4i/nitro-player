# android/ - Android Native Layer

> **Правила:** max 500 строк, БЕЗ истории, для AI

## Overview
- **Цель**: ExoPlayer (Media3 1.9.3) видеоплеер для Android
- **Принцип**: Nitro Hybrids (Kotlin <-> C++ JNI bridge), singleton VideoManager

## Файлы

### core/

| Файл | Назначение |
|------|------------|
| `VideoManager.kt` | Singleton: view/player registry, lifecycle. Все mutations через runOnMainThread |
| `AudioFocusManager.kt` | Audio focus request/release |
| `VideoError.kt` | Error sealed classes |

### core/player/

| Файл | Назначение |
|------|------------|
| `DRMManagerSpec.kt` | Interface stub (DRM disabled) |
| `DataSourceFactoryUtils.kt` | OkHttp DataSource factory (safe cast CookieJar) |
| `MediaItemUtils.kt` | ExoPlayer MediaItem builder |
| `MediaSourceUtils.kt` | MediaSource factory (safe cast drmManager) |
| `OnAudioFocusChangedListener.kt` | Audio focus change handler |

### core/utils/

Threading, SmallVideoPlayerOptimizer, SourceLoader, TextTrackUtils, VideoFileHelper, VideoInformationUtils, VideoOrientationUtils

### hybrids/

| Файл | Назначение |
|------|------------|
| `videoplayer/HybridVideoPlayer.kt` | ExoPlayer wrapper: native-first `PlaybackState` + `MemorySnapshot`, delayed offscreen trim |
| `videoplayersource/HybridVideoPlayerSource.kt` | Source retention states: cold / metadata / hot |
| `videoplayereventemitter/HybridVideoPlayerEventEmitter.kt` | JS event bridge for unified `onPlaybackState` + media events |
| `videoviewviewmanager/HybridVideoViewViewManager.kt` | View props/events |

### view/

| Файл | Назначение |
|------|------------|
| `VideoView.kt` | FrameLayout: surface/texture, resize, Android fullscreen/PiP, observer cleanup in detach |

### react/

| Файл | Назначение |
|------|------------|
| `VideoPackage.kt` | RN package: VideoView + HlsCacheProxyModule; единственная Android autolinking entrypoint |
| `VideoViewViewManager.kt` | Fabric view manager |

### com/yupi/hls/ - HLS Cache Proxy

| Файл | Назначение |
|------|------------|
| `HlsCacheProxyModule.kt` | RCT bridge + native autostart + LifecycleEventListener self-heal |
| `HlsCacheProxyServer.kt` | NanoHTTPD server + routes + safe prefetch (visitedUrls) |
| `HlsManifest.kt` | M3U8 parsing + rewriting |
| `HlsCacheStore.kt` | File cache: 5GB, 7d TTL, LRU, ConcurrentHashMap |
| `HlsHeaderCodec.kt` | Base64 header encoding/decoding |

## QC фиксы (текущее состояние)

- `HybridVideoPlayer`: `isReleased` guard предотвращает double release из close()/dispose()
- `VideoManager`: все mutations в runOnMainThread (thread safety)
- `VideoView`: globalLayoutListener сохраняется как field, removeOnGlobalLayoutListener в detach
- `VideoView`: removeCallbacks(layoutRunnable) в detach
- `VideoView`: re-register в `VideoManager` на attach после detach, чтобы `nitroId` lookup не терялся
- `HybridVideoPlayer`: progress/status/buffering сведены в единый `PlaybackState` snapshot
- `HybridVideoPlayer`: offscreen paused player может trim-иться до `metadata`/`cold` по `memoryConfig`
- `VideoManager` + `HybridVideoPlayer`: profile `feed` держит bounded hot pool (сейчас 2 игрока); активный/attached feed player остаётся hot, старые offscreen feed instances trim-ятся до `metadata`
- `HybridVideoPlayerSource`: metadata warmup отделён от hot `ExoPlayer.prepare()`
- `HlsCacheProxyModule`: safe null check `server?.isAlive != true`
- `HlsCacheProxyModule`: proxy auto-starts in native module init / first proxied URL lookup; JS app не обязан вызывать start()
- `HlsCacheProxyServer`: prefetch с visitedUrls set (no infinite recursion)
- `HlsCacheProxyServer` + `HlsCacheStore`: per-stream cache stats считаются по root manifest `streamKey`, который должен пробрасываться через nested manifests и segment requests
- `MediaSourceUtils`: safe cast `as?` для drmManager
- `DataSourceFactoryUtils`: safe cast `as?` для CookieJarContainer

## Build (build.gradle)

- Namespace: `com.twg.video`
- Kotlin: 2.1.20
- SDK: compile 36, target 36, min 24
- Media3: 1.9.3 (exoplayer, ui, common, datasource-okhttp)
- HLS proxy: nanohttpd 2.3.1
- Nitro: react-native-nitro-modules (JNI)
- Tests: `src/test` (JVM) + `src/androidTest` (instrumentation)

## Правила

1. `com.twg.video` namespace - НЕ менять (nitrogen JNI bindings)
2. DRMManagerSpec.kt - interface stub, НЕ удалять
3. VideoView public fullscreen/PiP entrypoints - НЕ удалять
4. nitrogen/generated/android/ - НЕ редактировать (autogen)
5. HLS proxy namespace: `com.yupi.hls` - отдельный
5.1. Отдельный `HlsCacheProxyPackage` не использовать; Android autolinking должен создавать только `new VideoPackage()`
6. HlsCacheProxyModule self-heals on onHostResume (LifecycleEventListener) и auto-starts без app bootstrap
7. VideoManager mutations - ТОЛЬКО через runOnMainThread
8. Android PiP работает только если host Activity поддерживает PiP в manifest/runtime
9. Playback state в JS идёт только через unified `PlaybackState`; не добавлять новые разрозненные player state events
10. Memory lifecycle идёт через `VideoConfig.memoryConfig`; `VideoView.detach` может инициировать delayed trim, если player offscreen и не играет
11. Feed surfaces не должны городить app-side hot-player manager; bounded hot pool живёт в `VideoManager` и вызывается через `touchFeedHotCandidate()`
