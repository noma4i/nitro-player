import { VideoPlayer } from '../VideoPlayer';
import type { PlaybackState } from '../types/PlaybackState';
type UsePlaybackStateOptions = {
    interpolate?: boolean;
    fps?: number;
};
export declare const usePlaybackState: (player: VideoPlayer | null | undefined, options?: UsePlaybackStateOptions) => PlaybackState | null;
export {};
//# sourceMappingURL=usePlaybackState.d.ts.map