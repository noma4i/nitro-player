import { type VideoPlayer as VideoPlayerImpl } from '../spec/nitro/VideoPlayer.nitro';
import type { VideoPlayerSource } from '../spec/nitro/VideoPlayerSource.nitro';
import type { IgnoreSilentSwitchMode } from './types/IgnoreSilentSwitchMode';
import type { MemorySnapshot } from './types/MemorySnapshot';
import type { MixAudioMode } from './types/MixAudioMode';
import type { PlaybackState } from './types/PlaybackState';
import type { TextTrack } from './types/TextTrack';
import type { NoAutocomplete } from './types/Utils';
import type { VideoConfig, VideoSource } from './types/VideoConfig';
import type { VideoPlayerBase } from './types/VideoPlayerBase';
import type { VideoPlayerStatus } from './types/VideoPlayerStatus';
import { VideoPlayerEvents } from './VideoPlayerEvents';
declare class VideoPlayer extends VideoPlayerEvents implements VideoPlayerBase {
    private _player;
    protected get player(): VideoPlayerImpl;
    constructor(source: VideoSource | VideoConfig | VideoPlayerSource, options?: {
        defaultMemoryProfile?: import('./types/MemoryConfig').MemoryProfile;
    });
    /**
     * Releases the player's native resources and releases native state.
     * @internal
     */
    __destroy(): void;
    /**
     * Returns the native (hybrid) player instance.
     * Should not be used outside of the module.
     * @internal
     */
    __getNativePlayer(): VideoPlayerImpl;
    /**
     * Handles parsing native errors to VideoRuntimeError and calling onError if provided
     * @internal
     */
    private throwError;
    /**
     * Updates the memory size of the player and its source. Should be called after any operation that changes the memory size of the player or its source.
     * @internal
     */
    private updateMemorySize;
    /**
     * Wraps a promise to try parsing native errors to VideoRuntimeError
     * @internal
     */
    private wrapPromise;
    get source(): VideoPlayerSource;
    get status(): VideoPlayerStatus;
    get playbackState(): PlaybackState;
    get memorySnapshot(): MemorySnapshot;
    get duration(): number;
    get volume(): number;
    set volume(value: number);
    get currentTime(): number;
    set currentTime(value: number);
    get bufferDuration(): number;
    get bufferedPosition(): number;
    get muted(): boolean;
    set muted(value: boolean);
    get loop(): boolean;
    set loop(value: boolean);
    get rate(): number;
    set rate(value: number);
    get mixAudioMode(): MixAudioMode;
    set mixAudioMode(value: MixAudioMode);
    get ignoreSilentSwitchMode(): IgnoreSilentSwitchMode;
    set ignoreSilentSwitchMode(value: IgnoreSilentSwitchMode);
    get playInBackground(): boolean;
    set playInBackground(value: boolean);
    get playWhenInactive(): boolean;
    set playWhenInactive(value: boolean);
    get isPlaying(): boolean;
    get isBuffering(): boolean;
    get isReadyToDisplay(): boolean;
    get showNotificationControls(): boolean;
    set showNotificationControls(value: boolean);
    initialize(): Promise<void>;
    preload(): Promise<void>;
    /**
     * Releases the player's native resources and releases native state.
     * After calling this method, the player is no longer usable.
     * Accessing any properties or methods of the player after calling this method will throw an error.
     * If you want to clean player resource use `replaceSourceAsync` with `null` instead.
     */
    release(): void;
    play(): void;
    pause(): void;
    seekBy(time: number): void;
    seekTo(time: number): void;
    replaceSourceAsync(source: VideoSource | VideoConfig | NoAutocomplete<VideoPlayerSource> | null): Promise<void>;
    getAvailableTextTracks(): TextTrack[];
    selectTextTrack(textTrack: TextTrack | null): void;
    get selectedTrack(): TextTrack | undefined;
}
export { VideoPlayer };
//# sourceMappingURL=VideoPlayer.d.ts.map