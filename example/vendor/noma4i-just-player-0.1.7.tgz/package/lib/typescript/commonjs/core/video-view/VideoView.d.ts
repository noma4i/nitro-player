import * as React from 'react';
import type { ViewProps, ViewStyle } from 'react-native';
import type { ListenerSubscription } from '../../spec/nitro/VideoPlayerEventEmitter.nitro';
import type { SurfaceType } from '../../spec/nitro/VideoViewViewManager.nitro';
import { type VideoViewEvents } from '../types/Events';
import type { ResizeMode } from '../types/ResizeMode';
import type { VideoConfig, VideoSource } from '../types/VideoConfig';
import { VideoPlayer } from '../VideoPlayer';
export interface VideoViewProps extends Partial<VideoViewEvents>, ViewProps {
    /**
     * Video source - URL string, asset number, or full VideoConfig.
     */
    source: VideoConfig | VideoSource;
    /**
     * Setup callback - configure the player when it's created.
     * @example
     * setup={(p) => { p.loop = true; p.volume = 0.5; }}
     */
    setup?: (player: VideoPlayer) => void;
    /**
     * The style of the video view - {@link ViewStyle}
     */
    style?: ViewStyle;
    /**
     * Whether to show the controls. Defaults to false.
     */
    controls?: boolean;
    /**
     * Whether to enable & show the picture in picture button in native controls. Defaults to false.
     */
    pictureInPicture?: boolean;
    /**
     * Whether to automatically enter picture in picture mode when the video is playing. Defaults to false.
     */
    autoEnterPictureInPicture?: boolean;
    /**
     * How the video should be resized to fit the view. Defaults to 'none'.
     * - 'contain': Scale the video uniformly (maintain aspect ratio) so that it fits entirely within the view
     * - 'cover': Scale the video uniformly (maintain aspect ratio) so that it fills the entire view (may crop)
     * - 'stretch': Scale the video to fill the entire view without maintaining aspect ratio
     * - 'none': Do not resize the video
     */
    resizeMode?: ResizeMode;
    /**
     * Whether to keep the screen awake while the video view is mounted. Defaults to true.
     */
    keepScreenAwake?: boolean;
    /**
     * The type of underlying native view. Defaults to 'surface'.
     * - 'surface': Uses a SurfaceView on Android. More performant, but cannot be animated or transformed.
     * - 'texture': Uses a TextureView on Android. Less performant, but can be animated and transformed.
     *
     * Only applicable on Android
     *
     * @default 'surface'
     * @platform android
     */
    surfaceType?: SurfaceType;
}
export interface VideoViewRef {
    /**
     * The player instance. Use for imperative control (play/pause/seek).
     */
    player: VideoPlayer;
    enterFullscreen: () => void;
    exitFullscreen: () => void;
    enterPictureInPicture: () => void;
    exitPictureInPicture: () => void;
    canEnterPictureInPicture: () => boolean;
    addEventListener: <Event extends keyof VideoViewEvents>(event: Event, callback: VideoViewEvents[Event]) => ListenerSubscription;
}
declare const _default: React.NamedExoticComponent<VideoViewProps & React.RefAttributes<VideoViewRef>>;
export default _default;
//# sourceMappingURL=VideoView.d.ts.map