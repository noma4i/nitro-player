import type { VideoPlayer } from '../../spec/nitro/VideoPlayer.nitro';
import type { VideoPlayerSource } from '../../spec/nitro/VideoPlayerSource.nitro';
import type { VideoConfig, VideoSource } from '../types/VideoConfig';
/**
 * @internal
 * Creates a Native VideoPlayer instance.
 *
 * @param source - The source of the video to play
 * @returns The Native VideoPlayer instance
 */
export declare const createPlayer: (source: VideoSource | VideoConfig | VideoPlayerSource) => VideoPlayer;
//# sourceMappingURL=playerFactory.d.ts.map