import type { Headers, HlsCacheStats, HlsStreamCacheStats } from './types';
declare class HlsCacheProxy {
    private defaultPort;
    private prefetchTimestamps;
    private prefetchDedupMs;
    private didWarnUnavailable;
    private didAutoStart;
    private isExplicitlyStopped;
    private warnUnavailable;
    private ensureStarted;
    start(port?: number): void;
    stop(): void;
    getProxiedUrl(url: string, headers?: Headers): string;
    prefetchFirstSegment(url: string, headers?: Headers): Promise<void>;
    getCacheStats(): Promise<HlsCacheStats>;
    getStreamCacheStats(url: string): Promise<HlsStreamCacheStats>;
    clearCache(): Promise<boolean>;
}
export declare const hlsCacheProxy: HlsCacheProxy;
export {};
//# sourceMappingURL=hlsCacheProxy.d.ts.map