# src/ - TypeScript Layer

> **Правила:** max 500 строк, БЕЗ истории, для AI

## Overview
- **Цель**: TypeScript public API для видеоплеера
- **Принцип**: `<VideoView source={} />` - единственный public component, player внутри

## Файлы

| Файл | Назначение | API |
|------|------------|-----|
| `index.tsx` | Re-exports | VideoView, VideoPlayer, useEvent, usePlaybackState, hlsCacheProxy, types |
| `core/video-view/VideoView.tsx` | Main component | `<VideoView source={} setup={} />`, player через ref |
| `core/hooks/useVideoPlayer.ts` | Internal hook | Вызывается из VideoView, НЕ экспортируется; `setup` применяется реактивно без пересоздания player |
| `core/hooks/useEvent.ts` | Event subscription | `useEvent(callback)` |
| `core/hooks/usePlaybackState.ts` | Playback UI hook | Native snapshot + JS interpolation |
| `core/hooks/useManagedInstance.ts` | Instance lifecycle | Internal |
| `core/video-view/NativeVideoView.tsx` | Fabric native component | Internal |
| `core/VideoPlayer.ts` | Player class | play/pause/seek + sync `playbackState` / `memorySnapshot` |
| `core/VideoPlayerEvents.ts` | Event type definitions | Internal |
| `core/utils/playerFactory.ts` | Nitro player factory | Internal |
| `core/utils/sourceFactory.ts` | Source factory + HLS auto-proxy | HLS manifest URLs auto-proxied, opt-out: useHlsProxy: false |

## Types (core/types/)

| Файл | Экспорт |
|------|---------|
| `VideoConfig.ts` | `VideoConfig` (uri, headers, useHlsProxy?, bufferConfig?, memoryConfig?, metadata?) |
| `MemoryConfig.ts` | `MemoryConfig`, preload/retention DSL |
| `MemorySnapshot.ts` | Sync native RAM snapshot |
| `VideoError.ts` | `VideoError`, `PlayerError`, `SourceError`, `LibraryError` |
| `VideoPlayerStatus.ts` | idle / loading / buffering / playing / paused / ended / error |
| `PlaybackState.ts` | Unified playback snapshot |
| `ResizeMode.ts` | none / cover / contain / stretch |
| `MixAudioMode.ts` | auto / mixWithOthers / doNotMix / duckOthers |
| `IgnoreSilentSwitchMode.ts` | auto / ignore / obey |
| `Events.ts` | Player/view events; playback state идёт через `onPlaybackState` |

## HLS Cache Proxy (hls/)

| Файл | API |
|------|-----|
| `hls/hlsCacheProxy.ts` | `hlsCacheProxy.start/stop/getProxiedUrl/prefetchFirstSegment/getCacheStats/getStreamCacheStats/clearCache`; lazy autostart on first HLS use |
| `hls/types.ts` | `HlsCacheStats`, `HlsStreamCacheStats`, `Headers`, `HlsCacheProxyNative` |

## Правила

1. `VideoView` принимает `source` prop - создаёт player внутри
2. `useVideoPlayer` - internal, НЕ экспортируется
3. Player доступен через `ref.current.player`
4. sourceFactory авто-проксирует HLS manifest URLs через hlsCacheProxy
5. sourceFactory НЕ мутирует входной `source`/`VideoConfig`; нормализация делается на копии
6. Nitro specs в `spec/nitro/` - контракт с нативом, менять = перегенерировать nitrogen
6.1. Каноничная команда перегенерации: `npm run codegen`
7. `setup` в `VideoView` реактивный: смена callback обновляет существующий player
8. `release()` должен делать JS player немедленно unusable
9. prefetchFirstSegment дедуплицирует вызовы (60s cooldown per URL)
10. TS contract tests живут в `src/__tests__/`
11. Playback UI source of truth = `player.playbackState` или `usePlaybackState()`
12. Memory lifecycle source of truth = `VideoConfig.memoryConfig`; JS не должен городить отдельную retention-логику поверх native policy
12.1. `profile: 'feed'` по умолчанию идёт через buffered preload + hot retention, но старые offscreen feed players должны trim-иться native manager-ом по bounded hot-pool policy
13. `hlsCacheProxy.start()` не должен быть обязательным шагом consumer app; обычный HLS playback обязан поднимать proxy автоматически
